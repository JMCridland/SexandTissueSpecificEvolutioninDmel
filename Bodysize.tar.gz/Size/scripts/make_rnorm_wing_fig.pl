#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $sex = shift(@ARGV) or die;
my $food = shift(@ARGV) or die;
my $output = "Rnorm_" . $sex . "_" . $food . ".R";
unlink(qq{$output});

opendir DIR, "$indir";
my @files = grep{/\.rnorm\.out/} readdir DIR;
closedir DIR;

my $outfile = "Rnorm_". $sex. "_" . $food . ".pdf";

open(A, ">>$output");
print A "sink(file=\"", "Wing.", $sex, ".", $food, ".txt", "\",append=FALSE,split=FALSE)\n";
foreach my $file (@files){
   # print $file, "\n";
    my @f = split(/\./, $file);
    if(($f[1] eq $sex) and ($f[2] eq $food)){
	
	my $x = $f[0] . "_" . $f[1] . "_" . $f[2];
	
	my $color = "black";
	if($f[0] =~ m/FFD/){
	    $color = "blue";
	}
	
	print A "x<-read.table(\"", $file, "\",header=TRUE)\n";
	print A "mod<-lm(x\$Length ~ x\$Temp)\n";
	print A "plot(x\$Temp,x\$Length, ylim=c(0.5,2),xlim=c(21,25),col=\"", $color, "\")\n";
	print A "print(paste(\"", $f[0], "\"))\n";
	print A "print(summary(mod))\n";
	print A "par(new=TRUE)\n";
	print A "abline(mod,col=\"", $color, "\")\n";
	print A "par(new=TRUE)\n";
    }
}
print A "sink()\n";
print A "legend(\"topleft\",legend=c(\"FFD\",\"PC\"),col=c(\"blue\",\"black\"),pch=c(20,20))\n";
print A "title(main=\"Wingsize Rnorm ", $sex, " ", $food, "\")\n";
print A "dev.copy2pdf(file=\"", $outfile, "\")\n";
close A;
