#!perl -w

use strict;

my $input = shift(@ARGV) or die; #Femursize.txt

####Making three new sets of comparisons
##Fed v Starve for each Sex/Temp combo

##Male v Female for each Temp/Food combo

##21 v 25 for Sex/Food

my %food = ();
my %sex = ();
my %temp = ();

open(A, "<$input");
while(my $line = <A>){
    chomp $line;
    my @a = split(/\t/, $line);
    if($line !~ m/Genotype/){

	my $food = 0;
	if($a[4] =~ m/F/){
	    $food = 1;
	}elsif($a[4] =~ m/Q/){
	    $food = 0.25;
	}
	
	if(!(exists($food{$a[0] . "\t" . $a[2] . "\t" . $a[3]}))){
	    my $out = "Femur.Food." . $a[0] . "." . $a[2] . "." . $a[3] . ".txt";
	    unlink(qq{$out});
	    $food{$a[0] . "\t" . $a[2] . "\t" . $a[3]} = 1;
	    open(X, ">>$out");
	    print X "Genotype\tTemp\tSex\tFood\tLength\n";
	    print X $a[0], "\t", $a[2], "\t", $a[3], "\t", $food, "\t", $a[6], "\n";
	    close X;
	    
	}elsif(exists($food{$a[0] . "\t" . $a[2] . "\t" . $a[3]})){
	    my $out = "Femur.Food." . $a[0] . "." . $a[2] . "." . $a[3] . ".txt";

	    open(X, ">>$out");
	    print X $a[0], "\t", $a[2], "\t", $a[3], "\t", $food, "\t", $a[6], "\n";
	    close X;
	}

	my $temp = 0;
	if($a[2] =~ m/High/){
	    $temp = 25;
	}elsif($a[2] =~ m/Low/){
	    $temp = 21;
	}

	if(!(exists($temp{$a[0] . "\t" . $a[3] . "\t" . $a[4]}))){
	    my $out = "Femur.Temp." . $a[0] . "." . $a[3] . "." . $a[4] . ".txt";
	    unlink(qq{$out});
	    $temp{$a[0] . "\t" . $a[3] . "\t" . $a[4]} = 1;
	    
	    open(X, ">>$out");
	    print X "Genotype\tTemp\tSex\tFood\tLength\n";
	    print X $a[0], "\t", $temp, "\t", $a[3], "\t", $a[4], "\t", $a[6], "\n";
	    close X;
	    
	}elsif(exists($temp{$a[0] . "\t" . $a[3] . "\t" . $a[4]})){
	    my $out = "Femur.Temp." . $a[0] . "." . $a[3] . "." . $a[4] . ".txt";
	    open(X, ">>$out");
	    print X $a[0], "\t", $temp, "\t", $a[3], "\t", $a[4], "\t", $a[6], "\n";
	    close X;
	}

	my $sex = 9;
	if($a[3] =~ m/M/){
	    $sex = 0;
	}elsif($a[3] =~ m/F/){
	    $sex = 1;
	}
	if(!(exists($sex{$a[0] . "\t" . $a[2] . "\t" . $a[4]}))){
	    my $out = "Femur.Sex." . $a[0] . "." . $a[2] . "." . $a[4] . ".txt";
	    unlink(qq{$out});
	    $sex{$a[0] . "\t" . $a[2] . "\t" . $a[4]} = 1;
	    
	    open(X, ">>$out");
	    print X "Genotype\tTemp\tSex\tFood\tLength\n";
	    print X $a[0], "\t", $a[2], "\t", $sex, "\t", $a[4], "\t", $a[6], "\n";
	    close X; 
	}elsif(exists($sex{$a[0] . "\t" . $a[2] . "\t" . $a[4]})){
	    my $out = "Femur.Sex." . $a[0] . "." . $a[2] . "." . $a[4] . ".txt";
	    open(X, ">>$out");
	    print X $a[0], "\t", $a[2], "\t", $sex, "\t", $a[4], "\t", $a[6], "\n";
	    close X; 
	}
    }
}
close A;
