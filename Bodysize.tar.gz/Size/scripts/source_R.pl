#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});

opendir DIR, "$indir";
my @files = grep{/\.R/} readdir DIR;
closedir DIR;

open(A, ">>$output");

foreach my $file (@files){
    if($file =~ m/Rnorm/){

	print A "source(\"", $file, "\")\n";

    }
}
close A;
