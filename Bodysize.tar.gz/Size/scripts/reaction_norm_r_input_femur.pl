#!perl -w

use strict;

#make R input for reaction norms - 

#I need norm of reaction for line,sex,fed combinations
#put Temp as a value so i can plot it that way?

my $input = shift(@ARGV) or die;
    
open(A, "<$input");

my %data = ();

while(my $line = <A>){
    chomp $line;
    my @a = split(/\t/, $line);
    if($line !~ m/Genotype/){
	my $out = $a[0] . "." . $a[3] . "." . $a[4] . ".femur.rnorm.out";
	
	my $temp = 0;
	if($a[2] =~ m/Low/){
	    $temp = 21;
	}elsif($a[2] =~ m/High/){
	    $temp = 25;
	}
	if(!(exists($data{$out}))){
	    $data{$out} = 1;
	    unlink(qq{$out});		
	    open(X, ">>$out");
	    print X "Line\tTemp\tSex\tFood\tLength\n";
	    print X $a[0], "\t", $temp, "\t", $a[3], "\t", $a[4], "\t", $a[6], "\n";
	    close X;
	}elsif(exists($data{$out})){
	    open(X, ">>$out");
	    print X $a[0], "\t", $temp, "\t", $a[3], "\t", $a[4], "\t", $a[6], "\n";
	    close X;
	}
    }
}
close A;
