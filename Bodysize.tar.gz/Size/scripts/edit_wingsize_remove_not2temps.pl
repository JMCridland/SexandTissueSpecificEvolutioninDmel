#!perl -w

#here I am removing all genotypes which don't have observations at both temperatures for some measurement category

my $input = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});

my %low = ();
my %high = ();

open(A, "<$input");
while(my $line = <A)
