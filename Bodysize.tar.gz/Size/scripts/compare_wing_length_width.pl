#!perl -w

use strict;

my $input = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});

my $tmpl = 0;

open(A, "<$input");
open(B, ">>$output");
print B "Genotype\tTemp\tPopulation\tSex\tFood\tCat\tL\tW\n";

LOOP:while(my $line = <A>){
    chomp $line;
    my @a = split(/\t/, $line);

    if($a[5] eq "l"){
	$tmpl = $a[7];
	next LOOP;
    }elsif($a[5] eq "w"){
    
	print B $a[0], "\t", $a[1], "\t", $a[2], "\t", $a[3], "\t", $a[4], "\t", $a[6], "\t", $tmpl, "\t", $a[7], "\n";
	next LOOP;
    }
}
close A;
close B;
