#!perl -w

use strict;

my $input = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});


my %data = ();

open(A, "<$input");
while(my $line = <A>){
	chomp $line;	
	my @a = split(/\t/, $line);
	if($line !~ m/Genotype/){
		if($a[5] eq "l"){
			if(!(exists($data{$a[0] . "\t" . $a[1] . "\t" . $a[3] . "\t" . $a[4]}))){
				$data{$a[0] . "\t" . $a[1] . "\t" . $a[3] . "\t" . $a[4]} = 1;
			}elsif(exists($data{$a[0] . "\t" . $a[1] . "\t" . $a[3] . "\t" . $a[4]})){
				$data{$a[0] . "\t" . $a[1] . "\t" . $a[3] . "\t" . $a[4]}++;
			}
		}
	}
}
close A;

open(B, ">>$output");
while((my $k, my $v) = each(%data)){
	print B $k, "\t", $v, "\n";

}
close B;
