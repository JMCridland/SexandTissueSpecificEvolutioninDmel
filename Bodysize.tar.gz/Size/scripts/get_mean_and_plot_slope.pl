#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});
my $outR = shift(@ARGV) or die;
unlink(qq{$outR});

opendir DIR, "$indir";
my @files = grep{/\.stats/} readdir DIR;
closedir DIR;

open(O, ">>$outR");
print O "sink(file=\"", $output, "\",append=FALSE,split=FALSE)\n";
foreach my $file (@files){
    my $pdf = $file;
    $pdf =~ s/\.stats/\.pdf/;
    
    print O "x<-read.table(\"", $file, "\", header=TRUE)\n";
    print O "hist(x\$Slope)\n";
    print O "abline(v=mean(x\$Slope),col=\"blue\")\n";
    print O "print(paste(\"", $file, "\"))\n";
    print O "print(mean(x\$Slope))\n";
    print O "dev\.copy2pdf(file=\"", $pdf, "\")\n";
}
print O "sink()\n";
close O;
