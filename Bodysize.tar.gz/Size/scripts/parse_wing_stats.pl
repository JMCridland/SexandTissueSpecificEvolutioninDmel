#!perl -w

use strict;

my $indir = shift(@ARGV) or die;

opendir DIR, "$indir";
my @files = grep {/\.out/} readdir DIR;
closedir DIR;

foreach my $file (@files){

    my @f = split(/\./, $file);
    my $output = $file;
    $output =~ s/\.out/\.stats/;
    unlink(qq{$output});
    
    my $val = $f[1];

    my $tmp = "";
    my %data = ();
    open(A, "<$file");
    open(B, ">>$output");
    print B "Line\tSlope\tRsq\tpval\n";
  LOOP:while(my $line = <A>){
      chomp $line;
      my @a = split(/\s+/, $line);
      if($line =~ m/\[1\]/){
	  $line =~ s/\[1\]//;
	  $line =~ s/\"//go;
	  $line =~ s/\s+//go;
	  $tmp = $line;
	  next LOOP;
      }elsif($line =~ m/$val/){
	  $data{$tmp} = $a[1];
	  next LOOP;
      }elsif($line =~ m/Multiple/){
	  $data{$tmp} = $data{$tmp} . "\t" . $a[5];
	  next LOOP;
      }elsif($line =~ m/F-statistic/){
	  if(!(exists($a[9]))){
	      $data{$tmp} = $data{$tmp} . "\t" . $a[8];
	  }else{
	      $data{$tmp} = $data{$tmp} . "\t" . $a[9];
	  }
	  next LOOP;
      }
      next LOOP;
  }
    close A;
    
    while((my $k, my $v) = each(%data)){
	
	print B $k, "\t", $v, "\n";
    }
    close B;

}
