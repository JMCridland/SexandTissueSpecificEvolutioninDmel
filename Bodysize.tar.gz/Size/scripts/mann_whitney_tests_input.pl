#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output}); #an .R file to run
my $out = shift(@ARGV) or die;
unlink(qq{$out});

opendir DIR, "$indir";
my @files = grep {/\.stats$/} readdir DIR;
closedir DIR;

open(A, ">>$output");

print A "sink(\"", $out, "\",append=TRUE,split=FALSE)\n";

foreach my $file (@files){

    if($file =~ m/FFD/){
	print $file, "\n";

	my $pc = $file;
	$pc =~ s/FFD/PC/;

	print A "print(paste(\"", $file, "\"))\n";
	print A "print(paste(\"", $pc, "\"))\n";
	
	print A "x<-read.table(\"", $file, "\", header=TRUE)\n"; 
	print A "y<-read.table(\"", $pc, "\", header=TRUE)\n";

	print A "test<-wilcox.test(x\$Slope,y\$Slope)\n";
	print A "print(test)\n";
    }
}
print A "sink()\n";
