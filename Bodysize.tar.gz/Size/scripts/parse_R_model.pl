#!perl -w

use strict;

my $input = shift(@ARGV) or die;
my $output = shift(@ARGV) or die;
unlink(qq{$output});

open(B, ">>$output");
open(A, "<$input");
while(my $line = <A>){
    chomp $line;
    my @a = split(/\t/, $line);
    
    if(($line =~ m/formula/) and ($line !~ m/aov/)){

#	print B $line, "\n";

    }
    if($line =~ m/\*/){
	print B $line, "\n";
    }
    if($line =~ m/p-value/){
	my @a = split(/,/, $line);
	$a[1] =~ s/\s+//go;
	print B $a[1], "\n";
    }
    if($line =~ m/R-squared/){
	my @a = split(/,/, $line);
	$a[1] =~ s/\s+//go;
	print B $a[1], "\n";
	
    }

}
close A;
close B;
