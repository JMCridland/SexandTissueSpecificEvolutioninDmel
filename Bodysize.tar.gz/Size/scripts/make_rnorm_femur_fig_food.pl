#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $sex = shift(@ARGV) or die;
my $temp = shift(@ARGV) or die;
my $output = "Rnorm_Food_FFD_" . $sex . "_" . $temp . ".R";
unlink(qq{$output});
my $output2 = "Rnorm_Food_PC_" . $sex . "_" . $temp . ".R";
unlink(qq{$output2});


opendir DIR, "$indir";
my @files = grep{/Femur\.Food/} readdir DIR;
closedir DIR;

my $outfile = "Rnorm_Food_FFD_". $sex . "_" . $temp . ".pdf";

my $outfile2 = "Rnorm_Food_PC_". $sex . "_" . $temp . ".pdf";

open(A, ">>$output");
print A "sink(file=\"", "Femur.Food.FFD.", $sex, ".", $temp, ".out", "\",append=FALSE,split=FALSE)\n";

open(B, ">>$output2");
print B "sink(file=\"", "Femur.Food.PC.", $sex, ".", $temp, ".out", "\",append=FALSE,split=FALSE)\n";
foreach my $file (@files){
    
    my @f = split(/\./, $file);
    if(($f[4] eq $sex) and ($f[3] eq $temp)){
#	print $file, "\n";
	
	#### first check file to see if it has both observations and can be included
	my %check = ();
	my $check = 0;
	open(X, "<$file");
	while(my $line = <X>){
	    chomp $line;
	    if($line !~ m/Genotype/){
		my @x = split(/\t/, $line);
		if(!(exists($check{$x[3]}))){
		 #   print $x[3], "\n";
		    $check{$x[3]} = 1;
		    $check++;
		}
	    }
	}
	close X;
#	print $check, "\n";
	if($check == 2){
	    
	    my $color = "black";
	    if($f[2] =~ m/FFD/){
		$color = "blue";
	    
		print A "x<-read.table(\"", $file, "\",header=TRUE)\n";
		print A "mod<-lm(x\$Length ~ x\$Food)\n";
		print A "plot(x\$Food,x\$Length, ylim=c(0.35,0.75),xlim=c(0,1),col=\"", $color, "\")\n";
		print A "print(paste(\"", $f[2], "\"))\n";
		print A "print(summary(mod))\n";
		print A "par(new=TRUE)\n";
		print A "abline(mod,col=\"", $color, "\")\n";
		print A "par(new=TRUE)\n";
	    }elsif($f[2] =~ m/PC/){
		print B "x<-read.table(\"", $file, "\",header=TRUE)\n";
		print B "mod<-lm(x\$Length ~ x\$Food)\n";
		print B "plot(x\$Food,x\$Length, ylim=c(0.35,0.75),xlim=c(0,1),col=\"", $color, "\")\n";
		print B "print(paste(\"", $f[2], "\"))\n";
		print B "print(summary(mod))\n";
		print B "par(new=TRUE)\n";
		print B "abline(mod,col=\"", $color, "\")\n";
		print B "par(new=TRUE)\n";

	    }
	}
    }
}
print A "sink()\n";
#print A "legend(\"topleft\",legend=c(\"FFD\",\"PC\"),col=c(\"blue\",\"black\"),pch=c(20,20))\n";
print A "title(main=\"Femur size Rnorm ", $sex, " ", $temp, "\")\n";
print A "dev.copy2pdf(file=\"", $outfile, "\")\n";
close A;

print B "sink()\n";
#print A "legend(\"topleft\",legend=c(\"FFD\",\"PC\"),col=c(\"blue\",\"black\"),pch=c(20,20))\n";
print B "title(main=\"Femur size Rnorm ", $sex, " ", $temp, "\")\n";
print B "dev.copy2pdf(file=\"", $outfile, "\")\n";
close B;
