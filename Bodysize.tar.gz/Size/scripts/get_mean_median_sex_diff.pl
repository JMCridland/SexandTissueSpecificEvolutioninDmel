#!perl -w

use strict;

my $input = shift(@ARGV) or die; #Femursize.txt
my $output = shift(@ARGV) or die;
unlink(qq{$output});

my %female = ();
my %male = ();
my %farray = ();
my %marray = ();

#columns are
#Genotype        Population      Temp    Sex     Food    Cat     Length

open(A, "<$input");
while(my $line = <A>){
    chomp $line;
    
    my @a = split(/\t/, $line);
    
    if($line !~ m/Genotype/){

	my $set = $a[0] . "\t" . $a[1] . "\t" . $a[2] . "\t" . $a[4];
	
	if($a[3] eq "F"){ #female
	    
	    push(@{$farray{$set}}, $a[6]);
	    
	    if(!(exists($female{$set}))){
		
		$female{$set} = $a[6];
		
	    }elsif(exists($female{$set})){
		
		$female{$set} = $female{$set} + $a[6];
		
	    }
	    
	}elsif($a[3] eq "M"){ #Male
	    
	    push(@{$marray{$set}}, $a[6]);
	    
	    if(!(exists($male{$set}))){
		
		$male{$set} = $a[6];
		
	    }elsif(exists($male{$set})){
		
		$male{$set} = $male{$set} + $a[6];
		
	    }
	}	    
    }
}
close A;

open(B, ">>$output");
print B "Genotype\tPopulation\tTemp\tFood\tFemaleMean\tFemaleMedian\tMaleMean\tMaleMedian\tMaleDivFemaleMean\tMaleDivFemaleMedian\n";
while((my $k, my $v) = each(%female)){
    
    if(exists($male{$k})){ #make sure there is data for both - if not check what's wrong

	my @msort = sort {$a <=> $b} @{$marray{$k}};

	my @fsort = sort {$a <=> $b} @{$farray{$k}};

	my $flen = scalar(@{$farray{$k}});
	my $mlen = scalar(@{$marray{$k}});

	my $fhalf = int($flen / 2);
	my $mhalf = int($mlen / 2);
	
	my $fmed = 0;
	my $mmed = 0;
	
	if(($flen % 2) == 0){ #even

	    $fmed = ((($fsort[$fhalf]) + ($fsort[$fhalf - 1])) / 2);
	    
	}elsif(($flen % 2) == 1){ #odd
	    
	    $fmed = ($fsort[$fhalf]);
	    
	}

	if(($mlen % 2) == 0){ #even

	    $mmed = ((($msort[$mhalf]) + ($msort[$mhalf - 1])) / 2);
	    
	}elsif(($mlen % 2) == 1){ #odd
	    
	    $mmed = ($msort[$mhalf]);
	    
	}

	my $fmean = ($female{$k} / $flen);

	my $mmean = ($male{$k} / $mlen);
	
	print B $k, "\t", sprintf("%.3f",$fmean), "\t", sprintf("%.3f",$fmed), "\t", sprintf("%.3f",$mmean), "\t", sprintf("%.3f",$mmed), "\t";

	print B  sprintf("%.3f",($mmean / $fmean)), "\t", sprintf("%.3f", ($mmed/$fmed)), "\n";
	
    }else{
#	print "Missing Males\n", die;
    }
}
close B;
