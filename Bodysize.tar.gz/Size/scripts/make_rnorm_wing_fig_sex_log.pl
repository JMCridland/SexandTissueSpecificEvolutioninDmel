#!perl -w

use strict;

my $indir = shift(@ARGV) or die;
my $temp = shift(@ARGV) or die;
my $food = shift(@ARGV) or die;
my $output = "Rnorm_Sex_FFD_" . $temp . "_" . $food . ".R";
unlink(qq{$output});
my $output2 = "Rnorm_Sex_PC_" . $temp . "_" . $food . ".R";
unlink(qq{$output2});

opendir DIR, "$indir";
my @files = grep{/Wing\.Sex/} readdir DIR;
closedir DIR;

open(A, ">>$output");
print A "sink(file=\"", "Wing.Sex.FFD.", $temp, ".", $food, ".out", "\",append=FALSE,split=FALSE)\n";

open(B, ">>$output2");
print B "sink(file=\"", "Wing.Sex.PC.", $temp, ".", $food, ".out", "\",append=FALSE,split=FALSE)\n";

foreach my $file (@files){
    
    my @f = split(/\./, $file);
    if(($f[3] eq $temp) and ($f[4] eq $food)){
	print $file, "\n";
	
	#### first check file to see if it has both observations and can be included
	my %check = ();
	my $check = 0;
	open(X, "<$file");
	while(my $line = <X>){
	    chomp $line;
	    if($line !~ m/Genotype/){
		my @x = split(/\t/, $line);
		if(!(exists($check{$x[2]}))){
	#	    print $x[2], "\n";
		    $check{$x[2]} = 1;
		    $check++;
		}
	    }
	}
	close X;
#	print $check, "\n";
	if($check == 2){
	    
	    my $color = "black";
	    if($f[2] =~ m/FFD/){
		$color = "blue";
	    
		print A "x<-read.table(\"", $file, "\",header=TRUE)\n";
		print A "mod<-lm(log(x\$Length) ~ x\$Sex)\n";
		print A "print(paste(\"", $f[2], "\"))\n";
		print A "print(summary(mod))\n";

	    }elsif($f[2] =~ m/PC/){

		print B "x<-read.table(\"", $file, "\",header=TRUE)\n";
		print B "mod<-lm(log(x\$Length) ~ x\$Sex)\n";
		print B "print(paste(\"", $f[2], "\"))\n";
		print B "print(summary(mod))\n";
	    }
	}
    }
}
print A "sink()\n";

print B "sink()\n";
close A;
close B;
